using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NaveAtira : MonoBehaviour
{
    [SerializeField] GameObject tiroPrefab;
    [SerializeField] float cadenciaDeTiro = 0.2f;
      

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.G))
        {

            Atirar();

        }
        if (Input.GetKeyUp(KeyCode.G))
        {
            CancelInvoke();
        }
        
    }

    void Atirar()
    {

        Instantiate(tiroPrefab,transform.position,transform.rotation);
        Invoke("Atirar", cadenciaDeTiro);
    }

    


}
