using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControleInimigo : MonoBehaviour
{
    Rigidbody2D fisica;
    Animator animacao;
    public Transform[] caminho;
    public LayerMask layerDoPlayer;//variavel para definnirmos qual e a layer que o inimigo vai progurar
    public float tempoParaPerderOPlayer = 3;
    float contadoeDeTempo = 0;

    public Vector2 direcao;

    int pontoAtual = 0;
    public float velocidade = 5;
    float distanciaAceitavel = 1;   






    [Header("Sobre ver o playes: ")]
    [Range(0,20)]
    public float distanciaVisao = 5;
    Transform vouSeguir;
    public float distanciaDoPlayer = 1.5f;

    // Start is called before the first frame update
    void Start()
    {
        fisica = GetComponent<Rigidbody2D>();
        animacao = GetComponent<Animator>();
        
    }

    // Update is called once per frame
    void Update()
    {
        direcao = caminho[pontoAtual].position - transform.position;
        float distancia = Vector2.Distance(transform.position, caminho[pontoAtual].position);

        if(distancia <= distanciaAceitavel)
        {
            pontoAtual++;
            if (pontoAtual >= caminho.Length)
            {
                pontoAtual = 0;
            }
        }
        //normalizar deixa no minimi -1 e maximo 1
        direcao.Normalize();

        if (vouSeguir)
        {
            direcao = vouSeguir.position - transform.position;
            direcao.Normalize();

            
        }

        //cria uma linha e ver se o jogador esta nela
        Debug.DrawRay(transform.position, direcao * distanciaVisao, Color.red);
        RaycastHit2D bateu = Physics2D.Raycast(transform.position, direcao, distanciaVisao,layerDoPlayer);
        if (bateu.collider)
        {
            Debug.Log("estou de vendo " + bateu.collider);
            vouSeguir = bateu.collider.transform;
            contadoeDeTempo = tempoParaPerderOPlayer;
        }
        else
        {
            Debug.Log("Onde voce esta?");
            if (vouSeguir)
            {
                contadoeDeTempo -= Time.deltaTime;
                if (contadoeDeTempo <= 0)
                {
                    vouSeguir = null;
                }
            }

        }

        if (vouSeguir)
        {
            float distanciaAtual = Vector2.Distance(transform.position, vouSeguir.position);
            if (distanciaAtual <= distanciaDoPlayer)
            {
                direcao = Vector2.zero;
            }
        }


        //manda andar na direcao        
        fisica.velocity = direcao * velocidade;


        if (direcao.x > 0.5f)
        {
            animacao.SetBool("cima", false);
            animacao.SetBool("esquerda", false);
            animacao.SetBool("direita", true);
            animacao.SetBool("baixo", false);
        }
        if (direcao.x < -0.5f)
        {
            animacao.SetBool("cima", false);
            animacao.SetBool("esquerda", true);
            animacao.SetBool("direita", false);
            animacao.SetBool("baixo", false);
        }
        if (direcao.y > 0.5f)
        {
            animacao.SetBool("cima", true);
            animacao.SetBool("esquerda", false);
            animacao.SetBool("direita", false);
            animacao.SetBool("baixo", false);
        }
        if (direcao.y < -0.5f )
        {
            animacao.SetBool("cima", false);
            animacao.SetBool("esquerda", false);
            animacao.SetBool("direita", false);
            animacao.SetBool("baixo", true);
        }


    }
}
